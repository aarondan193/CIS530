from asyncio.windows_events import NULL
from cgitb import text
from datetime import date
from django.forms import NullBooleanField


#grabbing the main webpage of links
import requests
r = requests.get('https://www.infoplease.com/primary-sources/government/presidential-speeches/state-union-addresses')


#connecting to sql database
import pyodbc 
cnxn = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                      "Server=DESKTOP-PDR3B56;"
                      "Database=Speeches;"
                      "Trusted_Connection=yes;")
cursor = cnxn.cursor()



#parsing the webpage
from bs4 import BeautifulSoup  
soup = BeautifulSoup(r.content, 'html.parser')  


#getting the links from the webpage
url = []
for link in soup.find_all('a'):
    url.append(link.get('href'))


#regex for /primary-sources/government/presidential-speeches/
import re
primarySpeechlinks= []
for u in url:
    x = re.search('\/primary-sources\/government\/presidential-speeches\/.', str(u))
    if (x is not None):
        primarySpeechlinks.append("https://www.infoplease.com" + x.string)


#removing duplicate links
unique_urls = list(set(primarySpeechlinks))

f = open("demofile2.txt", "a")

primarySpeechWebpages = []
for page in unique_urls:
    #gets each link from the unique_urls varible
    thepage = requests.get(page)

    primarySpeechWebpages.append(thepage.text)
    soup2 = BeautifulSoup(thepage.content, 'html.parser')
    speechText = soup2.getText()

    #finding the name and date from the webpage based on the : and ()
    partitioned_string = speechText.partition(':')
    name = (partitioned_string[2]).partition('(')[0]
    date = speechText.partition('(')[2]
    date = date.partition(')')[0]


    #finding the infoplease staff text, then the date, then the ). Everything after that is text
    text = speechText.partition('Infoplease Staff')[2]
    if (len(text.partition(date)[2]) > 500):
        text = text.partition(date)[2]
        text = text.partition(')')[2]
    




    #for the george bush speeches with no name or date listed. If the name is more than 50 characters, its not the name, but the text of the speech.
    if len(name) > 50:
        text = name
        name = None
    
    #removes extrenuous white space from before and after each variable
    if (name is not None):
        name = name.strip()

    if (date is not None):
        date = date.strip()

    if (page is not None):
        page = page.strip()
    
    if (text is not None):
        text = text.strip()
    
    #this adds an excape character for the sql insert statements. ' becomes ''
    text = text.replace("\'","\'\'")    

    #date = speechText.partition("("[2])

    #prepares the insert statement
    cmd = "INSERT INTO SPEECHES.dbo.SPEECHES values(\'" + str(name) + "\',\'" + str(date) + "\',\'" + str(page) + "\',\'"  + str(text) + "\')"

    #submitting the sql insert
    cursor.execute(cmd)
    #comminging the change after each insert
    cnxn.commit()
    #writing all the data to a file for extra credit
    f.write(str(name) + " " + str(date) + "\n" + text + "\n")


f.close()